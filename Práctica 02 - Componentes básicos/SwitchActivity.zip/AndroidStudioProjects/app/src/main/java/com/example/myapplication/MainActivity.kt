package com.example.SwitchActivity

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.switchactivity.R
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {
    //Instancias para componentes gráficos
    //Cajas de texto
    private lateinit var metros: EditText
    private lateinit var pies: RadioButton
    private lateinit var pulgadas: RadioButton
    private lateinit var yardas: RadioButton
    private lateinit var resultado: TextView
    private lateinit var opciones : RadioGroup
    //Declaración de instancia de clase
    private lateinit var obj: Convertidor
    //FORMATO PARA REPRESENTAR CANTIDAD DE DECIMALES
    private val formatoDecimales: DecimalFormat = DecimalFormat("#.##")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//Asociaciòn con objetos gràfico
        metros = findViewById(R.id.edtMetros)
        pies = findViewById(R.id.rbtPies)
        pulgadas = findViewById(R.id.rbtPulgadas)
        yardas = findViewById(R.id.rbtYardas)
        resultado = findViewById(R.id.txtResConversion)
        opciones = findViewById(R.id.rgpOpciones)
//Inicializar instancias de clase
        obj = Convertidor()
    }//onCreate
    fun onClick(v: View?){
//Identificar la opciòn seleccionada, por default la primera
        var opc: Int = 1
        when (v?.id) {
            R.id.btnConvertir -> {
                btnConvertir()
            }
            R.id.btnMostrar -> {
                btnMostrar()
            }
            R.id.btnLimpiar -> {
                btnLimpiar()
            }
        }//when
    }//onClick
    fun btnConvertir(){
//Validar que hay valor
        if(metros.text.isNotEmpty()){
// Obtener cantidad en metros
            obj.meter = metros.text.toString().toInt().toDouble()
// Evaluar la opciòn seleccionada para calcular
            if(pies.isChecked) obj.calculateFeet()
            if(pulgadas.isChecked) obj.calculateInch()
            if(yardas.isChecked) obj.calculateYard()
            Toast.makeText(applicationContext,"Metros convertidos.",
                Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(applicationContext,"Ingresa cantidad en metros.",
                Toast.LENGTH_SHORT).show()
        }
    }//btnConvertir
    fun btnMostrar(){
        var res: String = "Cantidad de metros convertida a: \n"
        res += "Pies: " + formatoDecimales.format(obj.feet) + "\n"
        res += "Pulgadas: " + formatoDecimales.format(obj.inch) + "\n"
        res += "Yardas: " + formatoDecimales.format(obj.yard) + "\n"
        resultado.text = res
    }//btnMostrar
    fun btnLimpiar(){
        metros.text = null
        resultado.text = "Cantidad de metros convertida a: \n"
        opciones.clearCheck()
        metros.requestFocus()
        obj = Convertidor()
    }//btnLimpiar

    // Clase Convertidor
    class Convertidor {
        var meter: Double = 0.0
        var feet: Double = 0.0
        var inch: Double = 0.0
        var yard: Double = 0.0

        // Funciones de conversión
        fun calculateFeet() {
            feet = meter * 3.28084
        }

        fun calculateInch() {
            inch = meter * 39.3701
        }

        fun calculateYard() {
            yard = meter * 1.09361
        }
    }
}