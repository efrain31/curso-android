package com.example.deportes

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var sharedPreferences: SharedPreferences

    lateinit var txtID: EditText
    lateinit var txtNombre: EditText
    lateinit var txtEdad: EditText
    lateinit var switchMayorEdad: Switch
    lateinit var radioGroupNivel: RadioGroup
    lateinit var cboxFutbol: CheckBox
    lateinit var cboxBasquetbol: CheckBox
    lateinit var cboxNatacion: CheckBox
    lateinit var cboxBox: CheckBox
    lateinit var cboxTaekwondo: CheckBox
    lateinit var imgbutAgregar: ImageButton
    lateinit var imgbutLimpiar: ImageButton
    lateinit var imgbutBuscar: ImageButton
    lateinit var txtDatos: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar los componentes
        txtID = findViewById(R.id.txtID)
        txtNombre = findViewById(R.id.txtNombre)
        txtEdad = findViewById(R.id.txtEdad)
        switchMayorEdad = findViewById(R.id.mayor) // Cambiado el Chip por Switch
        radioGroupNivel = findViewById(R.id.radioGroupNivel)
        cboxFutbol = findViewById(R.id.cboxFutbol)
        cboxBasquetbol = findViewById(R.id.cboxBasquebolt)
        cboxNatacion = findViewById(R.id.cboxNatacion)
        cboxBox = findViewById(R.id.cboxBox)
        cboxTaekwondo = findViewById(R.id.cboxTaekwondo)
        imgbutAgregar = findViewById(R.id.imgbutAgregar)
        imgbutLimpiar = findViewById(R.id.imgbutEliminar)
        imgbutBuscar = findViewById(R.id.imgbutBuscar)
        txtDatos = findViewById(R.id.txtDatos)

        // Inicializar SharedPreferences
        sharedPreferences = getSharedPreferences("DeportistaPrefs", Context.MODE_PRIVATE)

        // Botón agregar
        imgbutAgregar.setOnClickListener {
            guardarDatos()
        }

        // Botón limpiar
        imgbutLimpiar.setOnClickListener {
            limpiarCampos()
        }

        // Botón buscar
        imgbutBuscar.setOnClickListener {
            buscarDeportista()
        }

        // Escuchar cambios de estado en el Switch (mayor de edad)
        switchMayorEdad.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                Toast.makeText(this, "Es mayor de edad", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Es menor de edad", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun guardarDatos() {
        val id = txtID.text.toString()
        val nombre = txtNombre.text.toString()
        val edad = txtEdad.text.toString().toIntOrNull() ?: 0
        val mayorEdad = if (switchMayorEdad.isChecked) "Sí" else "No"

        // Obtener el nivel
        val nivel = when (radioGroupNivel.checkedRadioButtonId) {
            R.id.radbutProfesional -> "Profesional"
            R.id.radbutAmateur -> "Amateur"
            R.id.radbutAtleta -> "Atleta Olímpico"
            else -> ""
        }

        // Obtener disciplinas seleccionadas
        val disciplinas = mutableListOf<String>()
        if (cboxFutbol.isChecked) disciplinas.add("Fútbol")
        if (cboxBasquetbol.isChecked) disciplinas.add("Básquetbol")
        if (cboxNatacion.isChecked) disciplinas.add("Natación")
        if (cboxBox.isChecked) disciplinas.add("Boxeo")
        if (cboxTaekwondo.isChecked) disciplinas.add("Taekwondo")

        // Guardar los datos en SharedPreferences
        val editor = sharedPreferences.edit()
        editor.putString("id_$id", id)
        editor.putString("nombre_$id", nombre)
        editor.putInt("edad_$id", edad)
        editor.putString("mayorEdad_$id", mayorEdad)
        editor.putString("nivel_$id", nivel)
        editor.putString("disciplinas_$id", disciplinas.joinToString(", "))
        editor.apply()

        Toast.makeText(this, "Datos guardados", Toast.LENGTH_SHORT).show()
    }

    private fun limpiarCampos() {
        txtID.text.clear()
        txtNombre.text.clear()
        txtEdad.text.clear()
        switchMayorEdad.isChecked = false
        radioGroupNivel.clearCheck()
        cboxFutbol.isChecked = false
        cboxBasquetbol.isChecked = false
        cboxNatacion.isChecked = false
        cboxBox.isChecked = false
        cboxTaekwondo.isChecked = false
        txtDatos.text = ""
    }

    private fun buscarDeportista() {
        val id = txtID.text.toString()
        if (id.isEmpty()) {
            Toast.makeText(this, "Introduce un ID", Toast.LENGTH_SHORT).show()
            return
        }

        // Obtener los datos desde SharedPreferences
        val nombre = sharedPreferences.getString("nombre_$id", "No encontrado")
        val edad = sharedPreferences.getInt("edad_$id", 0)
        val mayorEdad = sharedPreferences.getString("mayorEdad_$id", "No")
        val nivel = sharedPreferences.getString("nivel_$id", "No encontrado")
        val disciplinas = sharedPreferences.getString("disciplinas_$id", "No encontrado")

        // Mostrar los datos en el TextView de forma vertical
        txtDatos.text = """
            ID: $id
            Nombre: $nombre
            +18: $mayorEdad
            Edad: $edad
            Nivel: $nivel
            Disciplinas: $disciplinas
        """.trimIndent()
    }
}

